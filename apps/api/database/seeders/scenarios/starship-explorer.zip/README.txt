A Quest Lab scenario: Starship Explorer
Exported 2026-11-18 20:37 UTC.

scenario.json is the scenario. assets/ holds the files uploaded for it; a media entry
whose "filepath" ends in one of those names uses that file.
Media that was not uploaded (it has an address but no file here) is loaded from that address.
To bring it back: in the editor, Scenarios > Import a ZIP. That makes a new scenario.
