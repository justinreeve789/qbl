A Quest Lab scenario: Science Lab

scenario.json is the scenario. Its backgrounds are not in this ZIP: they are loaded from
its asset_base_url (/scenario-assets/sciencelab), which the site serves from scenarios/assets.
To bring it back: in the editor, Scenarios > Import a ZIP. That makes a new scenario.
